import React from 'react';

const PetPage: React.FC = () => {
  return (
    <div>
      <h1 className='text-xxl text-center'>Pet Information</h1>
      <p>This page will display information about pets.</p>
    </div>
  );
};

export default PetPage;
